<link rel="stylesheet" href="<?= base_url('asset/bootstrap/css/bootstrap.min.css'); ?>" media="screen">
<link rel="stylesheet" href="<?= base_url('asset/plugins/select2/select2.min.css'); ?>" />
<link rel="stylesheet" href="<?= base_url('asset/dist/css/print_fullpage.css'); ?>" media="all"/>
<link rel="stylesheet" href="<?= base_url('asset/plugins/datatables/dataTables.bootstrap.css'); ?>" media="screen">
<link rel="stylesheet" href="<?= base_url('asset/plugins/tableexport/dist/css/tableexport.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('asset/font-awesome/css/font-awesome.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('asset/ionicons/css/ionicons.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('asset/dist/css/AdminLTE.min.css'); ?>" media="screen">

<style>body{font-size:11px !important;}p{margin:0px;}</style>